# Spectrometer Simulation

This is a simple UV-Vis simulation built with Vue and ChartJS.
